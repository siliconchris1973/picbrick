adafruit-pi-cam
===============

Camera project for Raspberry Pi + camera + Adafruit PiTFT
By PaintYourDragon (Phil B) for Adafruit Industries

Read how to build this project over at 
http://learn.adafruit.com/diy-wifi-raspberry-pi-touch-cam
Enjoy!
